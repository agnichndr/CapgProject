package com.capgemini.go.bean;

public enum Category {
	
	CAMPING,
	GOLF,
	MOUNTAINEERING,
	OUTDOOR,
	PERSONAL,

};
