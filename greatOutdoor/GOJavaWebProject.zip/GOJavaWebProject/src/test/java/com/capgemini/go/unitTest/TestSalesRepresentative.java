package com.capgemini.go.unitTest;

import static org.junit.jupiter.api.Assertions.*;

import java.net.ConnectException;

import org.junit.jupiter.api.Test;

import com.capgemini.go.dao.SalesRepresentativeDao;
import com.capgemini.go.dao.SalesRepresentativeDaoImpl;
import com.capgemini.go.exception.OrderNotFoundException;
import com.capgemini.go.exception.ProductNotFoundException;
import com.capgemini.go.exception.SalesRepresentativeException;
import com.capgemini.go.service.SalesRepresentativeService;
import com.capgemini.go.service.SalesRepresentativeServiceImpl;

class TestSalesRepresentative {

	@Test
	void orderIdNotFound() {
		SalesRepresentativeDao salesRepDao=new SalesRepresentativeDaoImpl();
		 assertThrows(SalesRepresentativeException.class,
		           () ->salesRepDao.checkDispatchStatus("OR1235"));
		         
	}
	
	@Test
	void checkDispatchStatusTrue() throws SalesRepresentativeException, ConnectException {
		SalesRepresentativeDao salesRepDao= new SalesRepresentativeDaoImpl();
		assertTrue(salesRepDao.checkDispatchStatus("OR123"));
	}
	
	@Test
	 void checkDispatchStatusFalse()throws SalesRepresentativeException, ConnectException{
		SalesRepresentativeDao salesRepDao=new SalesRepresentativeDaoImpl();
		assertFalse(salesRepDao.checkDispatchStatus("OR157"));
	}
	
	@Test 
	void validateUserTestException() {
		SalesRepresentativeDao salesRepDao=new SalesRepresentativeDaoImpl();
		assertThrows(SalesRepresentativeException.class,
		           () ->salesRepDao.validateUser("OR169"));
	}
	
	@Test
	void validateUserTest() throws ConnectException{
		try {
		SalesRepresentativeDao salesRepDao=new SalesRepresentativeDaoImpl();
		String user="SR02";
		assertEquals(user, salesRepDao.validateUser("OR234"));}
		catch(SalesRepresentativeException e) {}
	}
	
	@Test
	void getCountProductException() throws ConnectException {
		try {
		SalesRepresentativeDao salesRepDao=new SalesRepresentativeDaoImpl();
		assertEquals(2,salesRepDao.getCountProduct("OR234", "prod02"));}
		catch(SalesRepresentativeException e) {}
	}
	
	@Test
	void getCountProductException1() throws ConnectException  {
		try {
		SalesRepresentativeDao salesRepDao=new SalesRepresentativeDaoImpl();
		assertNotEquals(4,salesRepDao.getCountProduct("OR234", "prod02"));}
		catch(SalesRepresentativeException e) {}
		
	}
		
	@Test
	void getOrderProductMapException() {
		SalesRepresentativeDao salesRepDao=new SalesRepresentativeDaoImpl();
		assertThrows(SalesRepresentativeException.class, ()-> salesRepDao.getOrderProductMap("OR789"));
	}
	
	
	@Test
	void testOrder() throws Exception {
		SalesRepresentativeDao salesRepDao=new SalesRepresentativeDaoImpl();
		String orderId=salesRepDao.getOrderDetails("OR157");
		assertEquals("OR157",orderId);
	}
	
	@Test
	void testCancelOrderWrongOrderId() {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertThrows(OrderNotFoundException.class,() -> salesRepSer.cancelOrder("OR15213","SR01"));
	}
	
	@Test
	void testCancelOrderWrongUserId() {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertThrows(SalesRepresentativeException.class,() -> salesRepSer.cancelOrder("OR157","SR07"));
	}
	
	@Test
	void testCancelOrderOrderAlreadyDispatched() {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertThrows(OrderNotFoundException.class,() -> salesRepSer.cancelOrder("OR234","SR01"));
	}
	
	@Test
	void testCancelOrderNoProductInOrder() {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertThrows(OrderNotFoundException.class,() -> salesRepSer.cancelOrder("OR124","SR01"));
	}
	
	@Test
	void testCancelOrder() throws Exception {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertEquals("Order has been cancelled",salesRepSer.cancelOrder("OR157","SR01"));
	}
	
	
	@Test 
	void testCancelProductWrongQuantity() {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertThrows(ProductNotFoundException.class,() -> salesRepSer.cancelProduct("OR157","SR01","PROD06",5));
	}
	
	@Test
	void testCancelProduct() throws Exception {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertEquals("The given products are canceled",salesRepSer.cancelProduct("OR157","SR01","PROD06",2));
	}
	
	@Test
	void testCheckTargetSalesWrongId() {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertThrows(SalesRepresentativeException.class,() -> salesRepSer.checkTargetSales("SR21"));
	}
	
	@Test
	void testCheckTargetSales() throws Exception {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertEquals("Your target sales is 200.0 and target status is met", salesRepSer.checkTargetSales("sr01") );
	}
	
	@Test
	void testCheckBonusWrongId() {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertThrows(SalesRepresentativeException.class,() -> salesRepSer.checkBonus("SR21"));
	}

	@Test
	void testCheckBonus() throws Exception {
		SalesRepresentativeService salesRepSer = new SalesRepresentativeServiceImpl();
		assertEquals("Your bonus is 200.0",salesRepSer.checkBonus("sr01"));
	}


}
