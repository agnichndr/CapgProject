package com.capgemini.go.unitTest;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.ConnectException;

import org.junit.jupiter.api.Test;

import com.capgemini.go.dao.GoAdminDao;
import com.capgemini.go.dao.GoAdminDaoImpl;
import com.capgemini.go.dto.RetailerDTO;
import com.capgemini.go.dto.SalesRepDTO;
import com.capgemini.go.exception.RetailerException;
import com.capgemini.go.exception.SalesRepresentativeException;

class AdminModFunctionTest {

	@Test
	void testGetBonus() throws ConnectException {
		GoAdminDao ga= new GoAdminDaoImpl();
		SalesRepDTO sr=new SalesRepDTO("SR01");
		try {
			assertEquals(200.0, ga.getBonus(sr));
		} 
		
		catch (SalesRepresentativeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGetTarget() throws ConnectException {
		GoAdminDao ga = new GoAdminDaoImpl();
		SalesRepDTO sr = new SalesRepDTO("SR01");
		try {
			assertEquals(200.0, ga.getTarget(sr));
		}

		catch (SalesRepresentativeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGetDiscount() throws ConnectException {
		GoAdminDao ga = new GoAdminDaoImpl();
		RetailerDTO ret = new RetailerDTO("RT01");
		try {
			assertEquals(10.0, ga.getDiscount(ret));
		}

		catch (RetailerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}