package com.capgemini.go.unitTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.net.ConnectException;
import java.sql.Connection;
import java.sql.Date;

import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

import com.capgemini.go.dao.RetailerDao;
import com.capgemini.go.dao.RetailerDaoImpl;
import com.capgemini.go.dto.CartDTO;
import com.capgemini.go.dto.OrderDTO;
import com.capgemini.go.dto.RetailerDTO;
import com.capgemini.go.exception.DatabaseException;
import com.capgemini.go.exception.RetailerException;
import com.capgemini.go.service.RetailerService;
import com.capgemini.go.service.RetailerServiceImpl;
import com.capgemini.go.utility.DbConnection;

public class RetailerOrderTest {

	private static Connection connection = null;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {

	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		connection.close();
	}

	@BeforeEach
	void setUp() throws Exception {

	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test // Failed test case for addItemtoCart
	public void addItemToCartTest1() throws RetailerException, ConnectException {
		RetailerDao rdi = new RetailerDaoImpl();
		try {
			connection = DbConnection.getInstance().getConnection();
		} catch (DatabaseException e) {

			e.printStackTrace();
		}
		CartDTO cart = new CartDTO("prod01", "RT01", 40000);

		try {
			rdi.addItemToCart(cart);
		} catch (RetailerException e) {
			assertEquals(e.getMessage(), "Product is not available for the quantity ordered");
			// assert others
		}
	}

	@Test // Successful test case for addItemtoCart
	public void addItemToCartTest3() throws RetailerException, ConnectException {
		CartDTO cart = new CartDTO("prod07", "RT01", 2);
		RetailerService rdi = new RetailerServiceImpl();
		try {
			connection = DbConnection.getInstance().getConnection();
		} catch (DatabaseException e) {

			e.printStackTrace();
		}
		boolean b = rdi.addItemToCart(cart);
		assertEquals(true, b);
	}

	@Test   // Placing  the order which is already present
	public void placeOrderTest1() throws RetailerException, ConnectException{
		RetailerService rdi = new RetailerServiceImpl();
		try {
			connection = DbConnection.getInstance().getConnection();
		} catch (DatabaseException e) {

			e.printStackTrace();
		}
		Date d1= Date.valueOf("2019-07-23");
		Date d2= Date.valueOf("2019-07-24");
		OrderDTO order=new OrderDTO("OR124","RT01","AR",false,d1,d2);

		try {
			rdi.placeOrder(order);
		} catch (RetailerException e) {
			assertEquals(e.getMessage(), "Duplicate entry '"+order.getOrderId()+"' for key 'PRIMARY'");
			// assert others
		}
	}
	
	@Test  // Placing the right order
	public void placeOrderTest2() throws RetailerException, ConnectException{
		RetailerService rdi = new RetailerServiceImpl();
		try {
			connection = DbConnection.getInstance().getConnection();
		} catch (DatabaseException e) {

			e.printStackTrace();
		}
		Date d1= Date.valueOf("2019-07-27");
		Date d2= Date.valueOf("2019-07-28");
		OrderDTO order=new OrderDTO("OR200","RT01","AR234",false,d1,d2);
		boolean b=rdi.placeOrder(order);
		assertEquals(true,b);
	}
	
}
