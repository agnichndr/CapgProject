package com.capgemini.go.unitTest;

import static org.junit.jupiter.api.Assertions.*;

import java.net.ConnectException;
import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.go.dto.ProductDTO;
import com.capgemini.go.exception.DatabaseException;
import com.capgemini.go.exception.ProductMasterException;
import com.capgemini.go.service.ProductMasterServiceImpl;
import com.capgemini.go.service.UserService;
import com.capgemini.go.service.UserServiceImpl;
import com.capgemini.go.utility.DbConnection;

class TestProductMasterServices {

	
	private static Connection connection = null;
	private static ProductMasterServiceImpl productMaster = null;
	@BeforeAll
	static void setDatabase()
	{
		try {
			connection = DbConnection.getInstance().getConnection();
		} catch (DatabaseException e) {
			
			e.printStackTrace();
		}
	}
	
	@BeforeEach
	void getUser()
	{
		productMaster = new ProductMasterServiceImpl();
	}
	
	@AfterEach
	void closeUser()
	{
		productMaster = null;
	}
	
	
	@AfterAll
	static void closeDatabase()
	{
		try {
			connection.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		connection=null;
	}
	
	
	@Test
	@DisplayName("Product Category is not valid")
	void addProductFail2()
	{
		ProductDTO product = new ProductDTO("xxx", 0, "xxx", "xxx", "xxx", "xxx", 1, 10, "xxx");
		assertThrows(ProductMasterException.class, ()->{productMaster.addProduct(product);});
	}
	
	@Test
	@DisplayName("Product Id duplication ")
	void addProductFail3() throws ProductMasterException
	{
		ProductDTO product = new ProductDTO("prod04", 100, "xxx", "xxx", "xxx", "xxx", 1, 1,"xxx");
		assertThrows(ProductMasterException.class, ()->{productMaster.addProduct(product);});
	}
	
	@Test
	@DisplayName("Product Added succesfully")
	void addProductSuccess() throws ProductMasterException, ConnectException
	{
		ProductDTO product = new ProductDTO("xxx", 100, "xxx", "xxx", "xxx", "xxx", 1, 1,"xxx");
		assertTrue(productMaster.addProduct(product));
	}
	
	@Test
	@DisplayName("Product and connection is null in update Product")
	void updateProductFail()
	{
		assertThrows(NullPointerException.class, ()->{productMaster.updateProduct(null);});	
	}
	
	@Test
	@DisplayName("Product Category is not valid in Update Product")
	void updateProductFail2()
	{
		ProductDTO product = new ProductDTO("xxx", 0, "xxx", "xxx", "xxx", "xxx", 1, 10, "xxx");
		assertThrows(ProductMasterException.class, ()->{productMaster.updateProduct(product);});
	}
	
	@Test
	@DisplayName("Product Id donot exists for update product")
	void updateProductFail3()
	{
		ProductDTO product = new ProductDTO("xxxyyy", 0, "xxx", "xxx", "xxx", "xxx", 1, 1, "xxx");
		assertThrows(ProductMasterException.class, ()->{productMaster.updateProduct(product);});
	}
	
	@Test
	@DisplayName("Update Product Successfully")
	void updateProductSuccess() throws ProductMasterException, ConnectException
	{
		ProductDTO product = new ProductDTO("xxx", 1000, "", "", "", "", 0, 2, "");
		assertTrue(productMaster.updateProduct(product));
	}
	
	

	@Test
	@DisplayName("Product Id donot exists for delte product")
	void delteProductFail2()
	{
		
		assertThrows(ProductMasterException.class, ()->{productMaster.deleteProduct("xxx999");});
	}
	
	@Test
	@DisplayName("Product Deleted Successfully")
	void deleteProductSuccess() throws ProductMasterException, ConnectException
	{
		assertTrue(productMaster.deleteProduct("xxx"));
	}
	
	
	
	@Test
	@DisplayName("Product Id donot exists for increasing product quantity")
	void addExistingProductFail2()
	{
		ProductDTO product = new ProductDTO("xxx999", 0, "", "", "", "", 2, 0, "");
		assertThrows(ProductMasterException.class, ()->{productMaster.addExistingProduct(product);});
	}
	
	@Test
	@DisplayName("want to add quantity of a deleted product")
	void addExistingProductFail3()
	{
		ProductDTO product = new ProductDTO("xxx", 0, "", "", "", "", 2, 0, "");
		assertThrows(ProductMasterException.class, ()->{productMaster.addExistingProduct(product);});
	}
	
	
	
	@Test
	@DisplayName("Product Quantity increase successfully ")
	void addExistingProductSuccess() throws ProductMasterException, ConnectException
	{
		ProductDTO product = new ProductDTO("prod04", 0, "", "", "", "", 2, 0, "");
		assertTrue(productMaster.addExistingProduct(product));	
	}

}
