package com.capgemini.go.unitTest;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.net.ConnectException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.function.BooleanSupplier;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.capgemini.go.dao.GoAdminDao;
import com.capgemini.go.dao.GoAdminDaoImpl;
import com.capgemini.go.dao.RetailerDao;
import com.capgemini.go.dao.RetailerDaoImpl;
import com.capgemini.go.dto.FrequentOrderedDTO;
import com.capgemini.go.dto.RetailerDTO;
import com.capgemini.go.dto.SalesRepDTO;
import com.capgemini.go.exception.DatabaseException;
import com.capgemini.go.exception.GoAdminException;
import com.capgemini.go.exception.ProductMasterException;
import com.capgemini.go.exception.RetailerException;
import com.capgemini.go.exception.SalesRepresentativeException;
import com.capgemini.go.service.ProductMasterServiceImpl;
import com.capgemini.go.utility.DbConnection;
import com.capgemini.go.utility.PropertiesLoader;

public class FreqOrderTest {
	private static Connection  connection = null;
	private static RetailerDao retailer = null;
	private static GoAdminDao goadmin = null;

	private void assertFalse(String suggestFreqOrderProducts) {
	}

	@BeforeAll
	static void setDatabase() {
		try {
			Connection connection  = DbConnection.getInstance().getConnection();
		} catch (DatabaseException e) {

			e.printStackTrace();
		}
	}

	@BeforeEach
	void getUser() {
		retailer = new RetailerDaoImpl();
		goadmin = new GoAdminDaoImpl();
	}

	@AfterEach
	void closeUser() {
		retailer = null;
	}

	@AfterAll
	static void closeDatabase() {
		try {
			 connection.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		 connection = null;
	}

	@Test
	void testAddProducttoFreq01() throws RetailerException, ConnectException {

		FrequentOrderedDTO freqOrder = new FrequentOrderedDTO("SR02", "prod06", null);
		boolean freqOrderStatus = retailer.addProductToFreqOrderDB(freqOrder);
		assertTrue(freqOrderStatus);
	}

	@Test
	void testAddProducttoFreq02() throws RetailerException {

		FrequentOrderedDTO freqOrder = new FrequentOrderedDTO("PR01", "prod06", null);
		assertThrows(RetailerException.class, () -> {
			retailer.addProductToFreqOrderDB(freqOrder );
		});

	}

	@Test
	void testAddProducttoFreq03() throws RetailerException {

		FrequentOrderedDTO freqOrder = new FrequentOrderedDTO("PR01", "prod09", null);

		assertThrows(RetailerException.class, () -> {
			retailer.addProductToFreqOrderDB(freqOrder);
		});

	}

	@Test
	void TestingSuggestFreqOrderProducts01() throws GoAdminException, ConnectException {
		goadmin.suggestFreqOrderProducts("SR01" );
		assertEquals("prod06", goadmin.suggestFreqOrderProducts("SR01"));
	}

	@Test
	void TestingSuggestFreqOrderProducts02() throws GoAdminException, ConnectException {
		String retailerId = "RT01";
		String SuggestFreqOrderProducts = goadmin.suggestFreqOrderProducts(retailerId);
		assertFalse(SuggestFreqOrderProducts);
	}

}