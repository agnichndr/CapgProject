package com.capgemini.go.unitTest;

 

import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

 

import java.sql.Connection;

 

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

 

import com.capgemini.go.dto.AddressDTO;
import com.capgemini.go.dto.UserDTO;
import com.capgemini.go.exception.DatabaseException;
import com.capgemini.go.exception.GoAdminException;
import com.capgemini.go.exception.RetailerException;
import com.capgemini.go.service.GoAdminService;
import com.capgemini.go.service.GoAdminServiceImpl;
import com.capgemini.go.service.RetailerService;
import com.capgemini.go.service.RetailerServiceImpl;
import com.capgemini.go.utility.DbConnection;

 

public class RetailerAddressTest {
    private static Connection connection = null;
    private static RetailerService retailer = null;
    AddressDTO address = null;
    @BeforeAll
    static void setUpBeforeClass() throws Exception {
        try {
            connection = DbConnection.getInstance().getConnection();
        } catch (DatabaseException e) {
            
            e.printStackTrace();
        }
    }

 

    @AfterAll
    static void tearDownAfterClass() throws Exception {
        connection.close();
        connection = null;
        
    }

 

    @BeforeEach
    void setUp() throws Exception {
        retailer = new RetailerServiceImpl();
        
    }

 

    @AfterEach
    void tearDown() throws Exception {
        retailer = null;
    }
    @Test
    @DisplayName("Add address successfully")
    void addAddressTest() throws  RetailerException
    {
    address = new AddressDTO("SR01ADDOO6", "SR01", "8", "WifdE", "DGFdsfG", "GdwsHT", "2314356", true);
        assertTrue(retailer.addAddress(address));
    }

 

@Test
    @DisplayName("Add address Exception")
void addAddressTest01() throws  RetailerException
    {
    address = new AddressDTO("SR01ADDOO3", "SR01", "2", "WE", "DGFG", "GHT", "231456", true);
    
    assertThrows(RetailerException.class, () -> { retailer.addAddress(address);
 });
    
    
    
}
    
    @Test
    @DisplayName("Update address successfully")
    void updateAddressTest() throws  RetailerException
{
    address = new AddressDTO("SR01ADDOO6", "SR01", "8", "WifdErjh543t", "DGFdsegfG", "GdwsHTwe", "23143wedg56", true);
        assertTrue(retailer.updateAddress(address));
}
    

 

    @Test
    @DisplayName("Update address Exception")
void updateAddressTest01() throws  RetailerException
    {
    address = new AddressDTO("SR01ADDOO7", "SR01", "6", "updated", "updated", "updated", "updated", true);
    assertFalse(retailer.updateAddress(address));
    }
    }